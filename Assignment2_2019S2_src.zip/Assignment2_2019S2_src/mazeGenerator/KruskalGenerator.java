package mazeGenerator;

import maze.Maze;

public class KruskalGenerator implements MazeGenerator {

	@Override
	public void generateMaze(Maze maze) {
		// TODO Auto-generated method stub

	} // end of generateMaze()

} // end of class KruskalGenerator
