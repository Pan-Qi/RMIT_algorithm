
/**
 * Implementation of Mergesort.
 * 
 * @author jefcha
 */
public class MergeSort extends SortAlgorithm
{
	
	/**
	 * Sort array.
	 * 
	 * @param array Array to be sorted.
	 */
    public void sort(int[] array) {
        // IMPLEMENT ME
    } // end of sort()


    /**
     * Merge left and right into array.
     * 
     * @param left Left sub-array.
     * @param right Right sub-array.
     * @param array Merged array.
     */
    protected void merge(int[] left, int[] right, int[] array) {
	// IMPLEMENT ME
    } // end of merge()

} // end of class MergeSort
