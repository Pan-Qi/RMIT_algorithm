The data generation function in testFunction.java file.
We used the generation function in treeTest.java to generate the data in different tree sizes and test data sizes.
If for checking the data generation function,please go testFunction.java.
If run the whole testing, please go analysis.java.